import { cva, type VariantProps } from "class-variance-authority"
import type * as React from "react"

import { cn } from "@krew/ui/lib/utils"

const statusPill = cva(
  "inline-flex h-7 items-center gap-1.5 rounded-full px-2.5 text-sm font-medium whitespace-nowrap",
  {
    variants: {
      tone: {
        neutral: "bg-secondary text-secondary-foreground",
        primary: "bg-accent text-accent-foreground",
        success: "bg-success-soft text-success",
        warning: "bg-warning-soft text-warning",
        danger: "bg-danger-soft text-destructive",
      },
    },
    defaultVariants: { tone: "neutral" },
  }
)

type StatusPillProps = React.ComponentProps<"span"> & VariantProps<typeof statusPill>

/** A short state label: "Paid", "At risk", "Waiting for client". Colour is never the only signal. */
function StatusPill({ tone, className, children, ...props }: StatusPillProps) {
  return (
    <span data-slot="status-pill" className={cn(statusPill({ tone }), className)} {...props}>
      <span aria-hidden className="size-1.5 rounded-full bg-current" />
      {children}
    </span>
  )
}

export { StatusPill, statusPill }
