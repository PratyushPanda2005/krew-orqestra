import type { JobStage } from "@krew/schemas"

import { cn } from "@krew/ui/lib/utils"

/**
 * The job's journey as a strip of frames, like a contact sheet.
 * Done frames are ink, the current frame is rani, a frame that needs
 * attention is haldi. Used on the job page and, small, in the jobs list.
 */
const FRAMES = ["Brief", "Quote", "Advance", "Work", "Review", "Invoice", "Paid"] as const
type Frame = (typeof FRAMES)[number]

const stageToFrame: Record<JobStage, number> = {
  enquiry: 0,
  briefing: 0,
  quoted: 1,
  booked: 2,
  atRisk: 2,
  inProgress: 3,
  inReview: 4,
  approved: 5,
  invoiced: 5,
  paid: 6,
  closed: 7,
  lost: -1,
}

type StageRailProps = {
  stage: JobStage
  size?: "sm" | "lg"
  className?: string
}

function StageRail({ stage, size = "lg", className }: StageRailProps) {
  const current = stageToFrame[stage]
  const attention = stage === "atRisk"
  const lost = stage === "lost"
  const label = lost
    ? "Job lost"
    : current >= FRAMES.length
      ? "Job closed"
      : `Step ${current + 1} of ${FRAMES.length}: ${FRAMES[current]}${attention ? ", needs attention" : ""}`

  return (
    <div data-slot="stage-rail" className={cn("w-full", className)}>
      <ol aria-label={label} className={cn("flex w-full", size === "lg" ? "gap-1" : "gap-0.5")}>
        {FRAMES.map((frame: Frame, i) => {
          const state = lost ? "off" : i < current ? "done" : i === current ? (attention ? "attention" : "current") : "todo"
          return (
            <li
              key={frame}
              aria-current={state === "current" || state === "attention" ? "step" : undefined}
              className="flex min-w-0 flex-1 flex-col gap-1.5"
            >
              <span
                aria-hidden
                data-state={state}
                className={cn(
                  "relative block w-full rounded-[3px] border",
                  size === "lg" ? "h-7" : "h-2",
                  // sprocket holes along the top and bottom edge (large size only)
                  size === "lg" &&
                    "before:absolute before:inset-x-1.5 before:top-1 before:h-[3px] before:bg-[radial-gradient(circle,var(--sprocket)_1px,transparent_1.5px)] before:bg-[length:6px_3px] after:absolute after:inset-x-1.5 after:bottom-1 after:h-[3px] after:bg-[radial-gradient(circle,var(--sprocket)_1px,transparent_1.5px)] after:bg-[length:6px_3px]",
                  state === "done" && "border-foreground bg-foreground [--sprocket:var(--background)]",
                  state === "current" && "border-primary bg-primary [--sprocket:var(--primary-foreground)]",
                  state === "attention" && "border-warning bg-warning-soft [--sprocket:var(--warning)]",
                  state === "todo" && "border-input bg-card [--sprocket:var(--input)]",
                  state === "off" && "border-dashed border-input bg-transparent [--sprocket:transparent]"
                )}
              />
              {size === "lg" && (
                <span
                  className={cn(
                    "truncate text-xs",
                    state === "current" && "font-semibold text-primary",
                    state === "attention" && "font-semibold text-warning",
                    (state === "todo" || state === "off") && "text-muted-foreground"
                  )}
                >
                  {frame}
                </span>
              )}
            </li>
          )
        })}
      </ol>
    </div>
  )
}

export { StageRail, FRAMES as STAGE_FRAMES }
